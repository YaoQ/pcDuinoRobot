﻿By placing a custom service file (.servicexml) in this folder, that service will be automatically loaded next time you start ASU VIPLE.
Note that if there is a name conflict with a default offered service, your service will not be loaded.
When you export a service, that service is automatically copied to this folder.
To create a new custom service file, right click the Activity Block that you want to export, and click "Export as Service."